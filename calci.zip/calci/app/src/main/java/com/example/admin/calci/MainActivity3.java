package com.example.admin.calci;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity3 extends AppCompatActivity {
EditText et1;
Button b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13,b14,b15,b16,b17;
//float value2;
int ans;
    //float value1;
boolean maddition,msubtraction,mmultiplication,mdivision;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        et1=(EditText)findViewById(R.id.editText);
        //et2=(EditText)findViewById(R.id.editText2);
        //et3=(EditText)findViewById(R.id.editText3);
        b1=(Button)findViewById(R.id.button);
        b2=(Button)findViewById(R.id.button2);
        b3=(Button)findViewById(R.id.button3);
        b4=(Button)findViewById(R.id.button4);
        b5=(Button)findViewById(R.id.button5);
        b6=(Button)findViewById(R.id.button6);
        b7=(Button)findViewById(R.id.button7);
        b8=(Button)findViewById(R.id.button8);
        b9=(Button)findViewById(R.id.button9);
        b10=(Button)findViewById(R.id.button10);
        b11=(Button)findViewById(R.id.button11);
        b12=(Button)findViewById(R.id.button12);
        b13=(Button)findViewById(R.id.button13);
        b14=(Button)findViewById(R.id.button14);
        b15=(Button)findViewById(R.id.button15);
        b16=(Button)findViewById(R.id.button16);
        b17=(Button)findViewById(R.id.button17);
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText(et1.getText()+"0");
            }
        });
        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText(et1.getText()+"1");
            }
        });
        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText(et1.getText()+"2");
            }
        });
        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText(et1.getText()+"3");
            }
        });
        b10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText(et1.getText()+"4");
            }
        });
        b11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText(et1.getText()+"5");
            }
        });
        b12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText(et1.getText()+"6");
            }
        });
        b13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText(et1.getText()+"7");
            }
        });
        b14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText(et1.getText()+"8");
            }
        });
        b15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText(et1.getText()+"9");
            }
        });
        b16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText(et1.getText()+".");
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText(et1.getText()+"*");

            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText(et1.getText()+"+");
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText(et1.getText()+"-");
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText(et1.getText()+"/");
            }
        });
        b17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               /* value2=Float.parseFloat(et1.getText()+"");
                if(msubtraction==true) {
                    et1.setText(value1 - value2+"");
                    msubtraction = false;
                }
                if(maddition==true) {
                    et1.setText(value1 + value2 + "");
                    maddition = false;
                }
                if(mmultiplication==true) {
                    et1.setText(value1 * value2 + "");
                    mmultiplication = false;
                }
                if(mdivision==true) {
                    et1.setText(value1 / value2 + "");
                    mdivision = false;
                }*/
               String value=(et1.getText().toString());
               String[] a=value.split("\\+");
               int lenghts=a.length;
              // for(int j=0;j<a.length;j++){
                   //if(a[j]=="+"){
                       ans=add(a);
                  // }
                  /* else if(a[j]=="-"){
                       ans=sub(a);
                   }
                    else if(a[j]=="*"){
                       ans=mul(a);
                   }
                   else if(a[j]=="/"){
                       ans=div(a);
                   }*/
              // }

               String newone=Integer.toString(ans);
               et1.setText(newone);
            }
        });
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et1.setText("");
            }
        });


       /* b1.setOnClickListener(new View.OnClickListener() {
            float a,b,c;
            @Override
            public void onClick(View v) {
                a = Float.parseFloat(et1.getText().toString());
                b = Float.parseFloat(et2.getText().toString());
               add(a,b);
            }
            public void add(float a,float b){
                c=a+b;
                et3.setText(Float.toString(c));
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            float a,b,c;
            @Override
            public void onClick(View v) {
                a = Float.parseFloat(et1.getText().toString());
                b = Float.parseFloat(et2.getText().toString());
                add(a,b);
            }
            public void add(float a,float b){
                c=a-b;
                et3.setText(Float.toString(c));
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
           float a,b,c;
            @Override
            public void onClick(View v) {
                a = Float.parseFloat(et1.getText().toString());
                b = Float.parseFloat(et2.getText().toString());
                add(a,b);
            }
            public void add(float a,float b){
                c=a*b;
                et3.setText(Float.toString(c));
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            float a,b,c;
            @Override
            public void onClick(View v) {
                a = Float.parseFloat(et1.getText().toString());
                b = Float.parseFloat(et2.getText().toString());
                add(a,b);
            }
            public void add(float a,float b){
                c=a/b;
                et3.setText(Float.toString(c));
            }
        });
        b5.setOnClickListener(new View.OnClickListener() {
            float a,b,c;
            @Override
            public void onClick(View v) {
                a = Float.parseFloat(et1.getText().toString());
                b = Float.parseFloat(et2.getText().toString());
                add(a,b);
            }
            public void add(float a,float b){
                c=a%b;
                et3.setText(Float.toString(c));
            }
        });*/

    }
    public int add(String[] a){
        int total=0;
        for(int i=0;i<a.length;i++){
            total=total+Integer.parseInt(a[i]);
        }
        return  total;
    }
    /*public int sub(String[] a){
        int total=0;
        for(int i=0;i<a.length;i++){
            total=total-Integer.parseInt(a[i]);
        }
        return  total;
    }
    public int mul(String[] a){
        int total=0;
        for(int i=0;i<a.length;i++){
            total=total*Integer.parseInt(a[i]);
        }
        return  total;
    }
    public int div(String[] a){
        int total=0;
        for(int i=0;i<a.length;i++){
            total=total/Integer.parseInt(a[i]);
        }
        return  total;
    }*/
}
