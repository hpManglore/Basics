package com.example.hp.sort_new;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button b1;
    String num[];
    EditText t1;
    int[] numbers;
    TextView tv,tv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=(Button)findViewById(R.id.button);
        t1=(EditText)findViewById( R.id.out);
        tv=(TextView)findViewById(R.id.two);
        tv1=(TextView)findViewById(R.id.one);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num=t1.getText().toString().split(" ");
                for(int i=0;i<num.length;i++)
                {
                    for(int j=0;j<num.length-i-1;j++)
                    {
                        if(Float.parseFloat(num[j])>Float.parseFloat(num[j+1]))
                        {
                            String temp;
                            temp=num[j];
                            num[j]=num[j+1];
                            num[j+1]=temp;
                        }
                    }
                }
                String res=" ";
                for(int i=0;i<num.length;i++)
                {

                    res+=num[i]+"\n";
                }
                tv.setText(res);
            }
        });
    }
}
