package com.example.poonamprabhu.sort;

import android.renderscript.ScriptGroup;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Spannable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button button,button2;
    EditText edit;
    TextView res;
    int i,j,temp,num[];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        button = findViewById(R.id.b1);
        button2= findViewById(R.id.b2);
        edit = findViewById(R.id.e1);
        //  src = findViewById(R.id.t1);
        res = findViewById(R.id.t2);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bubblesort1();
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bubblesort2();
            }
        });
    }
        public void bubblesort1()
        {
            Spannable spn = edit.getText();
            num = new int[spn.length()];

            for (i = 0; i < spn.length(); i++) {
                num[i] = Integer.parseInt("" + spn.charAt(i));
            }

            for (i = 0; i < num.length; i++) {
                for (j = i + 1; j < num.length; j++) {
                    if (num[i] > num[j]) {
                        temp = num[i];
                        num[i] = num[j];
                        num[j] = temp;
                    }
                }
            }

            String result = " ";

            for (i = 0; i < num.length; i++) {
                result += num[i] + " ";
            }
            res.setText(result);
        }


    public void bubblesort2()
    {
        Spannable spn = edit.getText();
        num = new int[spn.length()];

        for (i = 0; i < spn.length(); i++) {
            num[i] = Integer.parseInt("" + spn.charAt(i));
        }

        for (i = 0; i < num.length; i++) {
            for (j = i + 1; j < num.length; j++) {
                if (num[i] < num[j]) {
                    temp = num[i];
                    num[i] = num[j];
                    num[j] = temp;
                }
            }
        }

        String result = " ";

        for (i = 0; i < num.length; i++) {
            result += num[i] + " ";
        }
        res.setText(result);
    }
    }
