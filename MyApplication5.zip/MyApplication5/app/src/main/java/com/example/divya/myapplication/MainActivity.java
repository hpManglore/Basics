package com.example.divya.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.divya.myapplication.R;

public class MainActivity extends AppCompatActivity {
    String[] arr;
    Button b1;
    int temp1;
    int [] num = new int[10];
    int count;
    EditText e1;
    TextView t1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1 = (Button)findViewById(R.id.button);
        e1 = (EditText) findViewById(R.id.editText);
        t1 = (TextView)findViewById(R.id.txt);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String abc;
                abc = e1.getText().toString();
                arr = abc.split(" ");
                for (String a: arr) {
                    num[count++] = Integer.parseInt(a);
                }

                for (int i=0;i<count;i++) {
                    for (int j = i + 1; j < count; j++) {
                        if (num[i] > num[j]) {
                            temp1 = num[i];
                            num[i] = num[j];
                            num[j] = temp1;
                        }
                    }
                }
                String res = " ";
                for(int a = 0; a < count; a++)

                {
                    res = res + Integer.toString(num[a]) + ",";
                }

                t1.setText(res);

            }



        });
    }
}
