package com.example.jenisa.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button b1, b2, b3, b4, b5, b6;
    EditText e1, e2, e3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = findViewById(R.id.button);
        b2 = findViewById(R.id.button2);
        b3 = findViewById(R.id.button3);
        b4 = findViewById(R.id.button4);
        b5 = findViewById(R.id.button5);
        b6 = findViewById(R.id.button6);
        e1 = findViewById(R.id.editText5);
        e2 = findViewById(R.id.editText3);
        e3 = findViewById(R.id.editText4);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int p = Integer.parseInt(e1.getText().toString());
                int q = Integer.parseInt(e2.getText().toString());
                mod(p, q);

            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int p = Integer.parseInt(e1.getText().toString());
                int q = Integer.parseInt(e2.getText().toString());
                sub(p, q);
            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int p = Integer.parseInt(e1.getText().toString());
                int q = Integer.parseInt(e2.getText().toString());
                div(p, q);
            }
        });

        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int p = Integer.parseInt(e1.getText().toString());
                int q = Integer.parseInt(e2.getText().toString());
                mul(p, q);
            }
        });
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int p = Integer.parseInt(e1.getText().toString());
                int q = Integer.parseInt(e2.getText().toString());
                add(p, q);
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                e1.setText("");
                e2.setText("");
                e3.setText("");
            }
        });
    }

    public void mod(int a, int b) {
        int c = a % b;
        String dd = Integer.toString(c);
        e3.setText(dd);
    }

    public void sub(int a, int b) {
        int c = a - b;
        String dd = Integer.toString(c);
        e3.setText(dd);

    }

    public void div(int a, int b) {
        int c = a / b;
        String dd = Integer.toString(c);
        e3.setText(dd);
    }

    public void mul(int a, int b) {
        int c = a * b;
        String dd = Integer.toString(c);
        e3.setText(dd);
    }

    public void add(int a, int b) {
        int c = a + b;
        String dd = Integer.toString(c);
        e3.setText(dd);
    }
}